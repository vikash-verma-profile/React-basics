import React,{Component} from 'react'
import './Mystyles.css'

function Stylessheet()
{
    return (
    <div>
        <h1 className="primary">Yuvraj Verma</h1>
    </div>
    )

}

export default Stylessheet