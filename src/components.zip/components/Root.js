import React,{Component} from 'react'
import {Router,Route} from 'react-router'

class Root extends Component{
    render() 
    {
        return (
           <div>
               hello
               </div>
            );
    }
}

export default Root