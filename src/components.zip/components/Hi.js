import React from 'react'

function Hi()
{
    return <h1> Hello </h1>
}

export default Hi