import React from 'react'

//can use anything in place of props but for conveson must use prop
const PropExample = (props) => {
console.log(props);

return <h1>Vikash prop {props.name} </h1>

}

export default PropExample