import React from 'react'

//  function Sample()
// {
//     return <h1> Hello vikash verma</h1>
// }

//this is in ES6
const Sample= () => <h1> Hello vikash </h1>


// if we are using default then we can import with any name else we have user 
// same name of the component we export it without default


export default Sample
  
