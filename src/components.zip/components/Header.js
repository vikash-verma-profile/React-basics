import React,{Component} from 'react'
 
export const Header=(props)=>{
    
        return (
            <div>
            <h3>Home</h3>
            <h3>User</h3>
            </div>
            );
}