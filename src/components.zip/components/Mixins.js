var SimpleMixin={
    getDefaultProps: function()
    {
        return {name:"skillbakery"};
    }
}
