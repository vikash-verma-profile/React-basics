import React from 'react'

function Temp()
{
    return <h1>HI bro</h1>
}

export default Temp